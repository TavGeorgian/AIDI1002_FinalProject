import torch
from transformers import GPT2Tokenizer, GPT2Model

def get_gpt_layer_representations(sequence_length, text_array, remove_chars, word_ind_to_extract):
    device = torch.device("cpu")  # Ensure CPU usage
    tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
    model = GPT2Model.from_pretrained("gpt2", output_hidden_states=True)
    model.to(device)

    # Initialize representations for each valid layer
    representations = {layer: [] for layer in range(model.config.n_layer)}

    for text in text_array:
        # Preprocess the input text
        for char in remove_chars:
            text = text.replace(char, "")
        
        # Tokenize the text
        inputs = tokenizer(text, return_tensors="pt", max_length=sequence_length, truncation=True)
        inputs = {key: val.to(device) for key, val in inputs.items()}  # Move inputs to CPU
        outputs = model(**inputs)
        hidden_states = outputs.hidden_states

        # Extract and store representations for valid layers
        for layer, state in enumerate(hidden_states):
            if layer < model.config.n_layer:  # Prevent indexing beyond valid layers
                valid_word_index = min(word_ind_to_extract, state.shape[1] - 1)  # Ensure valid index
                state = state[0, valid_word_index].detach().numpy()
                representations[layer].append(state)

    return representations
